import logo from './logo.svg';
import './App.css';
import NoteList from "./components/noteList";
import Tmp from "./components/tmp";

function App() {
  return (

    <div className="App flex flex-col items-center justify-center min-h-screen">

    <NoteList />


    </div>
  );
}

export default App;
