import logo from './logo.svg';
import './App.css';
import NoteList from "./components/noteList";
import Tmp from "./components/tmp";

function App() {
  return (

    <div className="App flex flex-col items-center justify-center min-h-screen">
    {/*<Tmp text='tmp1'/>*/}
    {/*  <Tmp text='tmp2'/>*/}
    {/*  <Tmp text='tmp3'/>*/}
    <NoteList />


    </div>
  );
}

export default App;
