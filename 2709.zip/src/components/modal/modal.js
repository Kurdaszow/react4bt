import { createPortal } from 'react-dom';
const Modal = ({ active, children }) => {
    return active && createPortal(
        <div className='absolute inset-0 backdrop-blur-md flex justify-center items-center'>
            <div className='flex flex-col bg-gray-200 rounded-xl p-10'>
                {children}
            </div>
        </div>,
        document.body
    )
}
 
export default Modal
 