
import Note from "./Note";
import {NOTES} from "./data";
import {useState} from "react";
const NoteList = () => {
const [currentNotes,setCurrentNotes] = useState(NOTES)
    const deleteNote = (noteId) => {
    setCurrentNotes(currentNotes.filter(
        (note) => (note.id !== noteId)
    ))
    }
    return (
        <div className="text-3xl bg-gray-300 h-auto w-1/3 rounded-2xl flex flex-col items-center justify-center p-1">

            {
                currentNotes.map(
                    (currentTitle, index) => (
                        <Note key={currentTitle.id} id={currentTitle.id} title={currentTitle.title} description={currentTitle.description} deleteNote={() => deleteNote(currentTitle.id)} />
                    )
                )

            }
        </div>
    );
}

export default NoteList;
