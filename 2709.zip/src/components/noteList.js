
import Note from "./Note";

const NoteList = ({children}) => {

    return (
        <div className="text-3xl bg-gray-300 h-auto w-1/3 rounded-2xl flex flex-col items-center justify-center p-1">
        <Note title="1" description="2"></Note>
            <Note title="2" description="2"></Note>
            <Note title="3" description="2"></Note>
            <Note title="4" description="2"></Note>

        </div>
    );
}

export default NoteList;
