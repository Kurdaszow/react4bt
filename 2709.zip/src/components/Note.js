import { useState } from "react"; // Import useState
import EditButton from "./editButton";
import DeleteButton from "./deleteButton";

const Note = ({ title, description }) => {
    const [show, setShow] = useState(false);

    const toggleVisibility = () => {
        setShow(!show);
    };

    return (
        <div className="relative  bg-cyan-50 rounded-3xl w-5/6 h-20 flex items-center justify-between m-1 p-1 pl-4">
            <div className="flex-grow text-left">
                <button className="flex-grow text-left" onClick={toggleVisibility}>
                    {title}
                </button>
                {show && <p>{description}</p>}
            </div>

            <div className="hover:text-indigo-500 bg-white rounded-3xl h-10 w-10 flex items-center justify-center">
                <EditButton />
            </div>

            <div className="hover:text-indigo-500 bg-white rounded-3xl h-10 w-10 flex items-center justify-center">
                <DeleteButton />
            </div>
        </div>
    );
};

export default Note;
