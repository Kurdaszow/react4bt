import { useState } from "react";
import EditButton from "./editButton";
import DeleteButton from "./deleteButton";
import Modal from "./modal/modal";


const Note = ({ title, description, deleteNote }) => {
    const [show, setShow] = useState(false);
    const [isModal, setIsModal] = useState(false);
    const [currentTitle,setCurrentTitle] = useState(title)
        const [currentDescription,setCurrentDescription] = useState(description)
    const toggleVisibility = () => {
        setShow(!show);
    };

    console.log('=======================')
    console.log('title', title)
    console.log('currentTitle', currentTitle)
    console.log('=======================')

    return (
        <div className="relative  bg-cyan-50 rounded-3xl w-5/6 h-20 flex items-center justify-between m-1 p-1 pl-4">
            <div className="flex-grow text-left">
                <button className="flex-grow text-left" onClick={toggleVisibility}>
                    {currentTitle}
                </button>
                {show && <p className="font-extralight">{currentDescription}</p>}
            </div>

            <button onClick={() => setIsModal(true)}   className="hover:text-indigo-500 bg-white rounded-3xl h-10 w-10 flex items-center justify-center">
                <EditButton />
            </button>

            <button className="hover:text-indigo-500 bg-white rounded-3xl h-10 w-10 flex items-center justify-center" onClick={deleteNote} >
                <DeleteButton />
            </button>
            <Modal active={isModal} setIsModal={setIsModal}>
                <h2 className='text-2xl font-bold mb-8'>Edit:</h2>
                <form className='flex flex-col gap-2'>
                    <label htmlFor='title'>Title:</label>
                    <input id='title' name='title' type='text' value={currentTitle}
                    onChange={(event)=> setCurrentTitle(event.target.value)}
                    />
                    <label htmlFor='description'>Description:</label>
                    <input id='description' name='description' type='text' value={currentDescription}
                    onChange={(event)=> setCurrentDescription(event.target.value)}
                    />
                    <button
                        onClick={() => setIsModal(false)}
                        type='button'
                        className='py-2 px-4 bg-white rounded hover:text-indigo-700 transition'
                    >
                        Save
                    </button>
                </form>
            </Modal>
        </div>
    );
};

export default Note;
