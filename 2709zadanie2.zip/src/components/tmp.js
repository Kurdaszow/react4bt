const Tmp = ({ text }) => {

    return (
        <>
        <p>{text}</p>
        <p>awojoajf</p></>
    );
}

export default Tmp