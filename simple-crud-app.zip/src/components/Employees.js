const Employees = [
  {
    Id : "1",
    Name: "Leandra",
    Surname: "zed",
    Age: "22"
  }  ,
  {
    Id : "12",
    Name: "Leaandra",
    Surname: "zeda",
    Age: "222"
  }

]
export default Employees;